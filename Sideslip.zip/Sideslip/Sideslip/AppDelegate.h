//
//  AppDelegate.h
//  Sideslip
//
//  Created by zhang on 2017/11/27.
//  Copyright © 2017年 app. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

