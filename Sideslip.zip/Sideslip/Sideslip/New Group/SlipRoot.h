//
//  SlipRoot.h
//  Sideslip
//
//  Created by zhang on 2017/11/27.
//  Copyright © 2017年 app. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SlipRoot : NSObject

- (UIViewController *)getSlipRootViewController;

@end
