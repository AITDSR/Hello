//
//  SlipRoot.m
//  Sideslip
//
//  Created by zhang on 2017/11/27.
//  Copyright © 2017年 app. All rights reserved.
//

#import "SlipRoot.h"
#import "RESideMenu.h"

#import "ViewController.h"
#import "LeftViewController.h"


@implementation SlipRoot

- (UIViewController *)getSlipRootViewController{
    
    ViewController *first = [[ViewController alloc] init];
    
    LeftViewController *leftMenuViewController = [[LeftViewController alloc] init];
    
    RESideMenu *sideMenuViewController = [[RESideMenu alloc] initWithContentViewController:first
                                                                    leftMenuViewController:leftMenuViewController
                                                                   rightMenuViewController:nil];
    sideMenuViewController.mainController = first;
    //    sideMenuViewController.menuPreferredStatusBarStyle = 1;
    
    sideMenuViewController.contentViewShadowColor = [UIColor blackColor];
    sideMenuViewController.contentViewShadowOffset = CGSizeMake(0, 0);
    sideMenuViewController.contentViewShadowOpacity = 1;
    sideMenuViewController.contentViewShadowRadius = 0;
    sideMenuViewController.contentViewShadowEnabled = YES;
    //是否缩小
    sideMenuViewController.scaleContentView = NO;
    
    return sideMenuViewController;
}

@end
