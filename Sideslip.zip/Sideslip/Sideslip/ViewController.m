//
//  ViewController.m
//  Sideslip
//
//  Created by zhang on 2017/11/27.
//  Copyright © 2017年 app. All rights reserved.
//

#import "ViewController.h"
#import "RESideMenu.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.view.backgroundColor = [UIColor lightGrayColor];
    
    //导航栏左按钮
    UIButton *leftButton = [UIButton buttonWithType:UIButtonTypeCustom];
    leftButton.frame = CGRectMake(10, 30, 40, 40);
//    [leftButtonItem setImage:[UIImage imageNamed:@"pic02"] forState:UIControlStateNormal];
    [leftButton setBackgroundImage:[UIImage imageNamed:@"pic02"] forState:UIControlStateNormal];
    
    [leftButton addTarget:self action:@selector(presentLeftMenuViewController:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:leftButton];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
