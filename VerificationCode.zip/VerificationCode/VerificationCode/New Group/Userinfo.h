//
//  Userinfo.h
//  VerificationCode
//
//  Created by zhang on 2017/11/27.
//  Copyright © 2017年 app. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Userinfo : NSObject

- (instancetype)initWithDictionary:(NSDictionary *)dictionary;

@property(nonatomic, copy, readonly) NSString *name;

@property (nonatomic, copy, readonly) NSString *age;

@end
