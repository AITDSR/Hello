//
//  Userinfo.m
//  VerificationCode
//
//  Created by zhang on 2017/11/27.
//  Copyright © 2017年 app. All rights reserved.
//

#import "Userinfo.h"

@implementation Userinfo

- (instancetype)initWithDictionary:(NSDictionary *)dictionary{
    
    self = self.init;
    
    if (self) {
        _name = dictionary[@"name"];
        _age = dictionary[@"age"];
    }
    return self;
}

//NSString *userinfoFilePath = [[NSBundle mainBundle]pathForResource:@"Userinfo" ofType:@"json"];
//NSString *userinfoFile = [[NSString alloc]initWithContentsOfFile:userinfoFilePath encoding:NSUTF8StringEncoding error:nil];
//NSData *data = [NSData dataWithContentsOfFile:userinfoFile];
//NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:nil];
//NSArray *arryFromJSON = dictionary[@"userinfo"];


@end
